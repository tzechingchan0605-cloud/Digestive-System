// 填入這個 VL 自己的公開 Apps Script /exec 網址，密碼不放此處。
window.VL1_CLOUD_CONFIG = Object.freeze({endpoint: ''});
